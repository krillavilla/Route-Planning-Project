Design Questions
=============

The authors sometimes fail to arrive at design decisions. Give us your thoughts!

radians as a separate type
-------------

Just as you shouldn't add metres to kilograms, so you shouldn't add radians to metres. Is the addition of a radian type overegging the pudding?

Has tau made the mainstream?
-------------

We have included constants for pi and tau. Do you know what tau is?