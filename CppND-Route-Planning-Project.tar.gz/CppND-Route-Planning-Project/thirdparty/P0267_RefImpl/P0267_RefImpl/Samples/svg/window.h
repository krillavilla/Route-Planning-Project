#pragma once
#include <string>

void RunWindowed( const std::string &path_in );
