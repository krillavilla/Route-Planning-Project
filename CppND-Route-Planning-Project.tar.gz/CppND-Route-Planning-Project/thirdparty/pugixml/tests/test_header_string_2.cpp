// Tests compatibility with string
#include <string>
#include "../src/pugixml.hpp"
