#include <iostream>
#include <string>
#include <optional>
#include <limits>
#include <fstream>
#include <vector>
#include "route_model.h"
#include "route_planner.h"
#include "render.h"

// Default map file path
static std::string default_map_path = "../map.osm";

// Function to parse command line arguments
std::string ParseArguments(int argc, char **argv) {
    std::string osm_file_path = default_map_path;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "-f" && i + 1 < argc) {
            osm_file_path = argv[i + 1];
            i++;
        }
    }

    return osm_file_path;
}

// Function to validate user input is within range 0-100
bool ValidateInput(float value) {
    return value >= 0.0f && value <= 100.0f;
}

// Function to read OSM data from file
std::vector<std::byte> ReadOSMData(const std::string &path) {
    std::vector<std::byte> osm_data;
    std::ifstream osm_file(path, std::ios::binary);

    if (!osm_file) {
        std::cerr << "Failed to open OSM file: " << path << std::endl;
        return osm_data;
    }

    osm_file.seekg(0, std::ios::end);
    const auto size = osm_file.tellg();
    osm_file.seekg(0, std::ios::beg);

    osm_data.resize(static_cast<size_t>(size));
    osm_file.read(reinterpret_cast<char *>(osm_data.data()), size);

    return osm_data;
}

int main(int argc, char **argv) {
    // Parse command line arguments
    std::string osm_file_path = ParseArguments(argc, argv);

    std::cout << "Reading OpenStreetMap data from: " << osm_file_path << std::endl;

    std::ifstream map_file(osm_file_path.c_str());
    if (!map_file) {
        std::cerr << "Error: Could not open the map file: " << osm_file_path << std::endl;
        return -1;
    }
    map_file.close();

    std::vector<std::byte> osm_data = ReadOSMData(osm_file_path);
    if (osm_data.empty()) {
        std::cerr << "Error: Could not read OSM data." << std::endl;
        return -1;
    }

    // Build Model and Prompt User for Coordinates
    RouteModel model{osm_data};
    float start_x, start_y, end_x, end_y;
    bool valid_input = false;

    while (!valid_input) {
        std::cout << "Enter start x coordinate (0-100): ";
        std::cin >> start_x;
        std::cout << "Enter start y coordinate (0-100): ";
        std::cin >> start_y;
        std::cout << "Enter end x coordinate (0-100): ";
        std::cin >> end_x;
        std::cout << "Enter end y coordinate (0-100): ";
        std::cin >> end_y;

        if (std::cin.fail() || 
            !ValidateInput(start_x) || !ValidateInput(start_y) || 
            !ValidateInput(end_x) || !ValidateInput(end_y)) {
            
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input! Coordinates must be numeric and in range 0-100.\n";
        } else {
            valid_input = true;
        }
    }

    // Run Route Planning
    RoutePlanner route_planner(model, start_x, start_y, end_x, end_y);
    route_planner.AStarSearch();
    std::cout << "Distance: " << route_planner.GetDistance() << " meters" << std::endl;

    // Render route if valid path exists
    Render render{model};
    auto path = route_planner.GetPath();

    if (!path.empty()) {
        render.Display(path);
    } else {
        std::cerr << "Error: No path was found. Skipping render." << std::endl;
    }

    return 0;
}
