#include "route_planner.h"
#include <algorithm>

// Constructor
RoutePlanner::RoutePlanner(RouteModel &model, float start_x, float start_y, float end_x, float end_y)
    : m_Model(model) {
    // Convert inputs to percentages
    start_x *= 0.01;
    start_y *= 0.01;
    end_x *= 0.01;
    end_y *= 0.01;

    // Find closest nodes to the coordinates
    start_node = &m_Model.FindClosestNode(start_x, start_y);
    end_node = &m_Model.FindClosestNode(end_x, end_y);
}

// Heuristic function: Euclidean distance to end node
float RoutePlanner::CalculateHValue(RouteModel::Node const *node) {
    return node->distance(*end_node);
}

// Add valid neighbors to the open list
void RoutePlanner::AddNeighbors(RouteModel::Node *current_node) {
    current_node->FindNeighbors();

    for (auto neighbor : current_node->neighbors) {
        if (!neighbor->visited) {
            neighbor->parent = current_node;
            neighbor->g_value = current_node->g_value + current_node->distance(*neighbor);
            neighbor->h_value = CalculateHValue(neighbor);
            neighbor->visited = true;
            open_list.push_back(neighbor);
        }
    }
}

// Return the next node with the lowest f = g + h
RouteModel::Node *RoutePlanner::NextNode() {
    std::sort(open_list.begin(), open_list.end(),
              [](const auto &a, const auto &b) {
                  return (a->g_value + a->h_value) > (b->g_value + b->h_value);
              });

    RouteModel::Node *lowest = open_list.back();
    open_list.pop_back();
    return lowest;
}

// Construct path from start to current node
std::vector<RouteModel::Node> RoutePlanner::ConstructFinalPath(RouteModel::Node *current_node) {
    distance = 0.0f;
    std::vector<RouteModel::Node> path;

    while (current_node != nullptr) {
        path.push_back(*current_node);
        if (current_node->parent) {
            distance += current_node->distance(*current_node->parent);
        }
        current_node = current_node->parent;
    }

    std::reverse(path.begin(), path.end());
    distance *= m_Model.MetricScale();
    return path;
}

// Perform A* Search
void RoutePlanner::AStarSearch() {
    start_node->visited = true;
    open_list.push_back(start_node);

    while (!open_list.empty()) {
        RouteModel::Node *current = NextNode();

        if (current == end_node) {
            // Build the final path for visualization
            m_Model.path = ConstructFinalPath(current);

            // Store path as pointers for rendering
            path_found.clear();
            for (const auto &node : m_Model.path) {
                path_found.push_back(const_cast<RouteModel::Node*>(&node));
            }
            return;
        }

        AddNeighbors(current);
    }

    // No path found
    path_found.clear();
    m_Model.path.clear();
}

// Return pointer-based path for rendering
std::vector<RouteModel::Node*> RoutePlanner::GetPath() const {
    return path_found;
}
